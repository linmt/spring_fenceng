create trigger TRG_EMP
	before insert
	on EMP
	for each row
begin
select SEQ_emp.nextval into:new.empno from dual;
end;
