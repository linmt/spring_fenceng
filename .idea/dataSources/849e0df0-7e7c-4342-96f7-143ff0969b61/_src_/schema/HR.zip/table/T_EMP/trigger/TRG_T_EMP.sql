create trigger TRG_T_EMP
	before insert
	on T_EMP
	for each row
begin
select SEQ_t_emp.nextval into:new.id from dual;
end;
